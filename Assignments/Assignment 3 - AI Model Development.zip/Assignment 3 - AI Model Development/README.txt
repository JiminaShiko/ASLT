ASLT Assignment 3 - AI Model Development

This submission contains both team models:
1. A static-sign photo model in "sign language photo model".
2. A sign-word video model in "videoModel", with cnn_gru and cnn3d architectures.

Each model folder contains its preprocessing/training code, trained checkpoint(s), dependencies, evaluation results, and instructions. The datasets are not copied. The photo model downloads its datasets as described in its README. The video model prepares/downloads datasets on the first training run; read and accept the WLASL and ASL Citizen dataset terms first.

Photo model
1. Open a terminal in "sign language photo model".
2. Run: pip install -r requirements.txt
3. Run: python train_model.py
4. To launch the app after training, run: streamlit run app.py

Video model
1. Open a terminal in "videoModel".
2. Run: python -m pip install -r requirements.txt
3. After reviewing the dataset terms, run: python -m src.train_model --models cnn_gru,cnn3d
4. To launch the app, run: python -m streamlit run streamlit_app.py

The combined model_evaluation_report.pdf summarizes the recorded held-out results for both model types. The photo model's detailed results and charts are in "sign language photo model/training_results". The video model's comparison table, metrics, confusion matrices, curves, and detailed report are in "videoModel/training_artifacts". The video-model results are low and have limited test support; see both the report and the model-specific README for limitations.
