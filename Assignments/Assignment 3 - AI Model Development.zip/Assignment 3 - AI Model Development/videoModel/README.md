# ASLT Video Sign Model

## Overview

Classifies short ASL video clips into sign-word labels using 16 sampled RGB frames
(112 x 112 pixels). Two configurations are included: CNN-GRU and CNN3D. The
training code preprocesses clips, trains both models, evaluates held-out data, and
saves checkpoints and evaluation charts.

## Run

Run commands from this folder:

```powershell
python -m pip install -r requirements.txt
python -m src.train_model --models cnn_gru,cnn3d
python -m streamlit run streamlit_app.py
```

Training prepares/downloads the datasets when they are not already available.
Review and accept the WLASL and ASL Citizen dataset terms before training. The
provided checkpoints can be used by the app without the training datasets.

To evaluate an individual video from the command line:

```powershell
python -m src.predict_video "path\to\video.mp4" --model cnn3d
```

## Evaluation

The supplied models were evaluated on a held-out test split (346 training, 92
validation, and 224 test clips):

| Model | Test accuracy | Macro F1 |
|---|---:|---:|
| CNN-GRU | 4.02% | 2.72% |
| CNN3D | 7.59% | 4.69% |

Results and charts are in `training_artifacts/`; trained
checkpoints are in `models/`. The test set has no examples for `eat` and has few
examples for some other words. These results are weak and do not demonstrate
reliable sign recognition.

## Limitations

The dataset is small and imbalanced, and some source videos are missing or
undecodable. Sampling only 16 frames can miss brief motion. Signer, background,
framing, and signing speed also affect predictions. Obtain source datasets
according to their terms; dataset files are not included in this project.
