ASLT PHOTO SIGN MODEL

OVERVIEW
--------
This MobileNetV2 image classifier recognizes 29 static-sign classes: A-Z, space,
del, and nothing. The shared preprocessing code detects and crops the hand and
resizes the image to 96 x 96 pixels. Training uses Sign Language MNIST and ASL
Alphabet data.

RUN
---
Run commands from this folder:

    python -m pip install -r requirements.txt
    python train_model.py
    streamlit run app.py

Training downloads the datasets when they are not already available. If the
MediaPipe hand-landmarker task file is missing, preprocessing downloads it.
Training saves the model as sign_photo_model.keras and writes results to
training_results/.

EVALUATION
----------
The supplied model was tested on data held out from training. Sign Language MNIST uses its official test partition; 10% of its official training partition is held out for validation. ASL Alphabet non-test images are split by class into 70% training, 15% validation, and 15% test, with official test images added only to the test set.


    Sign Language MNIST: 96.00% accuracy (7,172 images)
    ASL Alphabet:        91.28% accuracy (9,965 images)
    Combined:            93.25% accuracy (17,137 images)

The training-results folder contains test_results.txt, a confusion matrix, and
training curves. Test results are reported separately because the datasets
differ. Accuracy varies by sign; for example, K and R are more difficult than
many other classes.

LIMITATIONS
-----------
Predictions depend on hand detection, pose, camera angle, lighting, and the
signer's hand. Some images cannot be cropped as a hand and are skipped during
preprocessing. These image-based test results do not guarantee performance for
new signers or live camera conditions.

Optional: capture your own signs with `python calibrate_camera.py`, then run
`python train_model.py --calibrate-only` to fine-tune the model. Check the
reported test results after calibration for any performance trade-offs.
